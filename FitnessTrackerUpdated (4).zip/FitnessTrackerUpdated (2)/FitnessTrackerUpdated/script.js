// JavaScript for Fitness Tracker Dashboard


document.addEventListener('DOMContentLoaded', () => {
    // Sidebar navigation functionality
    const links = document.querySelectorAll('.nav-link');
    links.forEach(link => {
        link.addEventListener('click', (e) => {
            const page = e.target.getAttribute('data-page');
            loadPage(page);
        });
    });

    // Hover animations for cards
    const animatedElements = document.querySelectorAll('.hover-animate');
    animatedElements.forEach(element => {
        element.addEventListener('mouseover', () => {
            element.classList.add('active');
        });
        element.addEventListener('mouseout', () => {
            element.classList.remove('active');
        });
    });

    // Functionality for Activity card click
    const activityCard = document.querySelector('.activity-card');
    if (activityCard) {
        activityCard.addEventListener('click', () => {
            loadPage('activity');
        });
    }

    // Load page function
    function loadPage(page) {
        if (page) {
            window.location.href = `${page}.html`;
        }
    }

    // Subscribe button click functionality
    const subscribeButton = document.querySelector('#subscribe-button');
    if (subscribeButton) {
        subscribeButton.addEventListener('click', () => {
            window.location.href = 'subscribe.html';
        });
    }
});
